Snippets that were previously shipped with the GNU ELPA yasnippet package.
