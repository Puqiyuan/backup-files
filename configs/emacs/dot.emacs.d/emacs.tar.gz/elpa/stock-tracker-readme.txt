Tool for tracking stock price in Emacs

Below are commands you can use:
`stock-tracker-start'
Start stock-tracker and display stock information with buffer
