wgrep-helm allows you to edit a helm-grep-mode buffer and apply those
changes to the file buffer.
