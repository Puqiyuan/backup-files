This package provides a simple command to restart Emacs from within Emacs


