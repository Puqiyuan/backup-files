This is a tool to manually explore and test HTTP REST
webservices.  Runs queries from a plain-text query sheet, displays
results as a pretty-printed XML, JSON and even images.
