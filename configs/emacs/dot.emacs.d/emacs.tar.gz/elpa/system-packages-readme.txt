This is a package to manage installed system packages.  Useful
functions include installing packages, removing packages, listing
installed packages, and others.

Helm users might also be interested in helm-system-packages.el
<https://github.com/emacs-helm/helm-system-packages>

Usage:

(require 'system-packages)
