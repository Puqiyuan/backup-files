writeroom-mode is a minor mode for Emacs that implements a
distraction-free writing mode similar to the famous Writeroom editor for
OS X. writeroom-mode is meant for GNU Emacs 24 and isn't tested on older
versions.

See the README or info manual for usage instructions.
