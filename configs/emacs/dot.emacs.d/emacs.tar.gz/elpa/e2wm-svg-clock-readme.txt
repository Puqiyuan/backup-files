e2wm plugin for svg-clock.
