This mode allows to paste whole buffers or parts of buffers to
pastebin-like services.  It supports more than one service and will
failover if one service fails.  More services can easily be added
over time and preferred services can easily be configured.
