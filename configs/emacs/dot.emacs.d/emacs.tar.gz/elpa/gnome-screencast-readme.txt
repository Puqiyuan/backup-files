Gnome screen recording integration in Emacs
