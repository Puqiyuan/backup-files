leerzeichen is a minor mode to display whitespace characters. That's all it
does, and it imposes little overhead by using a buffer local display table
rather than the font-lock functionality.

More information: https://github.com/fgeller/leerzeichen.el/
