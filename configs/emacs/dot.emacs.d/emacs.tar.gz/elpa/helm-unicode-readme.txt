A helm command for looking up unicode characters by name 😉.
