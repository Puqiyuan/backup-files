Treefactor provides commands to incrementally refile files in Dired and to
refactor outlines. It allows Org mode to manage a dynamic meta-outline
combining both the directory hierarchy and outlines within files.

Read the manual at

  https://treefactor-docs.nfshost.com
