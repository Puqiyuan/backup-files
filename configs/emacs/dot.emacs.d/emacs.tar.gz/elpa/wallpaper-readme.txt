Ricing `exwm' is pretty cool, but even cooler is being able to manage
everything about your rice using Emacs.  This package is meant to
make that a little bit easier, by managing your wallpapers for you.

The provided modes are `wallpaper-cycle-mode' for cycling randomly
through wallpapers in a directory, and `wallpaper-per-workspace-mode'
for setting a specific wallpaper or wallpapers in each workspace or
a window manager.

The following window managers are known to work with this package:
- EXWM
- Any that use vdesk for virtual desktops

The following might work but aren't fully tested:
- i3

Compatibility is only guaranteed with use of an X desktop session.
