Reveal current file in folder.
