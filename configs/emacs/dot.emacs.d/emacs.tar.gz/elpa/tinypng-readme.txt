Compress PNG and JEPG via https://tinypng.com/ API.
