This package provide integration between Emacs window and tmux pane.
For more information see the README in the github repo.
