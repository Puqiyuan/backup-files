Please read the fine manual which is available in the doc
directory. We do our best to make sure that it's up to date and
informative.
