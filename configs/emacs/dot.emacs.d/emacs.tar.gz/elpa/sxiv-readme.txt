The sole command and primary entry point is `sxiv'.

`sxiv-filter' is the process filter, to insert subdirectories (via
`sxiv-insert-subdirs') and mark files marked in sxiv (via
`sxiv-dired-mark-files').
