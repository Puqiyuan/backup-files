QUickstart:

1) Add your directory to load path
(add-to-load-path "~/vcs/emms-bilibili")

2) import emms-bilibill
(require 'emms-bilibili)

3) run it
[M-x emms-bilibili]
