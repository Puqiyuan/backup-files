Smart-Dash mode is a minor mode which redefines the dash key to
insert an underscore within C-style identifiers and a dash
otherwise.
