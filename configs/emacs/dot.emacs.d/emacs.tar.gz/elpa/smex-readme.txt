Quick start:
run (smex-initialize)

Bind the following commands:
smex, smex-major-mode-commands

For a detailed introduction see:
http://github.com/nonsequitur/smex/blob/master/README.markdown
