This package makes it easy to browse and read RFC documents.
