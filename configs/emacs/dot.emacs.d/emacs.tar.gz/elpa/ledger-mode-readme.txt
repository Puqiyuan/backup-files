Most of the general ledger-mode code is here.
