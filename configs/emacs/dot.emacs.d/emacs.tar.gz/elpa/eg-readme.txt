eg.el provides code for reading the content of help databases built with
Norton Guide and Expert Help. It also provides commands for viewing and
navigating the content of Norton Guide files.

The main command is `eg'. Run this, select a Norton Guide database to
view, and off you go.
