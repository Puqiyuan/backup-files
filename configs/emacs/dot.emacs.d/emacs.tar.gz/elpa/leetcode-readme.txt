leetcode.el is an unofficial LeetCode client.

Now it implements several API:
- Check problems list
- Try testcase
- Submit code

Since most HTTP requests works asynchronously, it won't block Emacs.
